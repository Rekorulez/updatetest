cd ./module

bash startBS.sh
