import os
from datetime import datetime
from time import sleep
import subprocess
from multiprocessing import Process
import re
command = ["python", "main.py"]

def measure_temp():
	t = os.popen("vcgencmd measure_temp").readline()
	t = re.sub("[^0-9]", "", t)
	return int(t)/10

def espera_troca_dissipador(p):
	p.kill()

def roda_teste():
	start_time = datetime.now()
	print("Starting BS")
	p = subprocess.Popen(command)
	while 1:
		t = measure_temp()
		print("Medi ", t)
		if t > 60:
			p.kill()
			return datetime.now() - start_time
		sleep(1)
testes = []
while 1:
	tempo = roda_teste()
	print("Tempo para o thermal throttoling: ", tempo)
#	c = input("Troque o dissipador, entao aperte ENTER, ou digite q para sair\n")#
	testes.append(tempo)
#	if c == "q": break
	sleep(1)
open("thermal_tests.json", "w").write(json.dumps(list(enumerate(testes)), indent = 4))
