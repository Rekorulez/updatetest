#!/bin/bash
pwd
source activate
#python3 main.py
python3 monitor_temperature.py
