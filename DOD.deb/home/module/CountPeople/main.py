import cv2
import numpy as np
from datetime import datetime
from pytz import timezone
import os
import matplotlib.pyplot as plt
import csv
import time as tm
# joblib
saveArea = savePoint = False
mouseX = mouseY = 0


def iou(x1_a, y1_a, x2_a, y2_a, x1_b, y1_b, x2_b, y2_b):  # retorn the intersection
    w_a = x2_a - x1_a
    w_b = x2_b - x1_b
    if x1_b <= x1_a and x2_b > x1_a and x2_a > x2_b:
        w_i = x2_b - x1_a
    elif x1_b < x2_a and x2_b >= x2_a and x1_a < x1_b:
        w_i = x2_a - x1_b
    elif x1_b > x1_a and x2_b < x2_a:
        w_i = w_b
    elif x1_b <= x1_a and x2_b >= x2_a:
        w_i = w_a
    else:
        w_i = 0
    h_a = y2_a - y1_a
    h_b = y2_b - y1_b
    if y1_b <= y1_a and y2_b > y1_a and y2_a > y2_b:
        h_i = y2_b - y1_a
    elif y1_b < y2_a and y2_b >= y2_a and y1_a < y1_b:
        h_i = y2_a - y1_b
    elif y1_b > y1_a and y2_b < y2_a:
        h_i = h_b
    elif y1_b <= y1_a and y2_b >= y2_a:
        h_i = h_a
    else:
        h_i = 0
    A_a = w_a * h_a
    A_b = w_b * h_b
    A_i = w_i * h_i  # intersection
    return A_i / (A_a + A_b - A_i + 1e-6)


def rgb2hsv_specific(frame, specific):
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(frame)
    if specific == 'h':
        frame = h
    elif specific == 's':
        frame = s
    else:
        frame = v
    return frame


def rgb2ycbcr_specific(frame, specific):
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
    y, cb, cr = cv2.split(frame)
    if specific == 'y':
        frame = y
    elif specific == 'cb':
        frame = cb
    else:
        frame = cr
    return frame


def normalization(Frame):
    frame_sum = (Frame.sum(2) + 1e-5)
    Frame[:, :, 0] = Frame[:, :, 0] / frame_sum*255
    Frame[:, :, 1] = Frame[:, :, 1] / frame_sum*255
    Frame[:, :, 2] = Frame[:, :, 2] / frame_sum*255
    return Frame


def image_processing(Frame, frame_bkgrnd, white, seconds, mog, absdiff=False, filled=False, kernel=None, kernel2=None, sampling_period=5, history=10):


    Frame = cv2.GaussianBlur(Frame, (7,7), 0)
    pre_processing = Frame.copy()
    if mog and absdiff:
        frame_fgbg = fgbg.apply(Frame)
        _, frame_fgbg = cv2.threshold(frame_fgbg, 128, 255, cv2.THRESH_BINARY)
        Frame[:, :, 0] = cv2.absdiff(Frame[:, :, 0], frame_bkgrnd[:, :, 0])
        Frame[:, :, 1] = cv2.absdiff(Frame[:, :, 1], frame_bkgrnd[:, :, 1])
        Frame[:, :, 2] = cv2.absdiff(Frame[:, :, 2], frame_bkgrnd[:, :, 2])
        Frame = cv2.cvtColor(Frame, cv2.COLOR_BGR2GRAY)
        _, Frame = cv2.threshold(Frame, 50, 255, cv2.THRESH_BINARY)
        Frame = cv2.erode(Frame, kernel)
        Frame = cv2.add(Frame, frame_fgbg)
    elif mog:
        Frame = fgbg.apply(Frame)
        _, Frame = cv2.threshold(Frame, 128, 255, cv2.THRESH_BINARY)
    elif absdiff:
        Frame[:, :, 0] = cv2.absdiff(Frame[:, :, 0], frame_bkgrnd[:, :, 0])
        Frame[:, :, 1] = cv2.absdiff(Frame[:, :, 1], frame_bkgrnd[:, :, 1])
        Frame[:, :, 2] = cv2.absdiff(Frame[:, :, 2], frame_bkgrnd[:, :, 2])
        Frame = cv2.cvtColor(Frame, cv2.COLOR_BGR2GRAY)
        _, Frame = cv2.threshold(Frame, 50, 255, cv2.THRESH_BINARY)
    if filled:
        _, Contours, _ = cv2.findContours(Frame, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE);
        cv2.drawContours(Frame, Contours, -1, (255,255,255), thickness=cv2.FILLED);


    run = False
    update[0] = False
    update[1] = False
    if len(white) == 0 or seconds[1] - seconds[0] >= sampling_period:
        print('1')
        white.append(np.sum((cv2.threshold(Frame.copy(), 127, 1, cv2.THRESH_BINARY)[1])))
        seconds[0] = seconds[1]
        run = True
    if run:
        if np.abs((white[-1]-np.mean(white))) < 1000:
            print('0')
    if len(white) > history:
        del white[0]
    return [Frame, pre_processing, update, white]


def detections(frame, threshold_detection, threshold_multi):
    coords = []
    bndboxes = []
    _, Contours, _ = cv2.findContours(frame, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for i in range(len(Contours)):
        coords.append(cv2.boundingRect(Contours[i]))
        if coords[i][2] * coords[i][3] >= threshold_detection:
            x1 = coords[i][0]
            y1 = coords[i][1]
            x2 = coords[i][0] + coords[i][2]
            y2 = coords[i][1] + coords[i][3]
            iter = int((x2 - x1) / threshold_multi)
            if iter >= 1:
                delta_x = int((x2 - x1) / (iter + 1))
                for i in range(iter + 1):
                    bndboxes.append({'x1': x1 + delta_x * i, 'y1': y1, 'x2': x1 + delta_x * (i + 1), 'y2': y2})
            else:
                bndboxes.append({'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2})
    return bndboxes


def calc_velocity(x1_a, y1_a, x2_a, y2_a, x1_b, y1_b, x2_b, y2_b):
    l = 80
    vector_1 = [(x1_b - x1_a), (y1_b - y1_a)]
    vector_2 = [(x2_b - x2_a), (y2_b - y2_a)]
    vector = [vector_1[0] + vector_2[0], vector_1[1] + vector_2[1]]
    speed = (vector[0] ** 2 + vector[1] ** 2) ** 0.5 + 1e-5
    vector = [int(vector[0] * l / speed), int(vector[1] * l / speed)]

    center_x = int((x2_b - x1_b) / 2) + x1_b
    center_y = int((y2_b - y1_b) / 2) + y1_b

    velocity_vector = {'x1': center_x, 'y1': center_y, 'x2': vector[0] + center_x, 'y2': vector[1] + center_y}
    return velocity_vector


def calc_velocities(bndboxes_old, bndboxes_new):
    velocity_vectors = []
    for bndbox_a in bndboxes_old:
        for bndbox_b in bndboxes_new:
            if bndbox_a['id'] == bndbox_b['id']:
                x1_a = bndbox_a['x1']
                y1_a = bndbox_a['y1']
                x2_a = bndbox_a['x2']
                y2_a = bndbox_a['y2']
                x1_b = bndbox_b['x1']
                y1_b = bndbox_b['y1']
                x2_b = bndbox_b['x2']
                y2_b = bndbox_b['y2']
                velocity_vectors.append(calc_velocity(x1_a, y1_a, x2_a, y2_a, x1_b, y1_b, x2_b, y2_b))
                velocity_vectors[-1]['id'] = bndbox_a['id']
    return velocity_vectors


def find_a_in_b(bndboxes_old, bndboxes_new, threshold_tracking):
    best_IOU = [0] * len(bndboxes_old)
    who_a_in_b = []
    idx_a = 0
    for bndbox_a in bndboxes_old:
        x1_a = bndbox_a['x1']
        y1_a = bndbox_a['y1']
        x2_a = bndbox_a['x2']
        y2_a = bndbox_a['y2']
        idx_b = 0
        who_a_in_b.append({'a_is_in_b': False, 'index_a': idx_a, 'index_b': None})
        # print('1)\t',who_a_in_b,idx_a)
        for bndbox_b in bndboxes_new:
            x1_b = bndbox_b['x1']
            y1_b = bndbox_b['y1']
            x2_b = bndbox_b['x2']
            y2_b = bndbox_b['y2']
            IOU = iou(x1_a, y1_a, x2_a, y2_a, x1_b, y1_b, x2_b, y2_b)
            if IOU >= best_IOU[idx_a]:
                best_IOU[idx_a] = IOU
                if best_IOU[idx_a] >= threshold_tracking:
                    who_a_in_b[idx_a] = {'a_is_in_b': True, 'index_a': idx_a, 'index_b': idx_b}
            # print('2)\t', who_a_in_b,idx_a,idx_b)
            idx_b += 1
        idx_a += 1
    return who_a_in_b


def tracking(bndboxes_old, bndboxes_new, threshold_tracking, last_id):
    who_a_in_b = find_a_in_b(bndboxes_old, bndboxes_new, threshold_tracking)
    for a in who_a_in_b:
        color = tuple((255 * np.random.rand(3)))
        if a['a_is_in_b']:
            if not ('id' in bndboxes_old[a['index_a']]):
                bndboxes_old[a['index_a']]['id'] = last_id
                bndboxes_new[a['index_b']]['id'] = last_id
                bndboxes_old[a['index_a']]['color'] = color
                bndboxes_new[a['index_b']]['color'] = color
                last_id += 1
            else:
                bndboxes_new[a['index_b']]['id'] = bndboxes_old[a['index_a']]['id']
                bndboxes_new[a['index_b']]['color'] = bndboxes_old[a['index_a']]['color']
        # else:
        #     bndboxes_new.append(bndboxes_old[a['index_a']])
        #     if not ('lost' in bndboxes_new[-1]):
        #         bndboxes_new[-1]['lost'] = 0
        #     elif bndboxes_new[-1]['lost'] >= 2:
        #         del bndboxes_new[-1]
        #     else:
        #         bndboxes_new[-1]['lost'] += 1

    idx = 0
    for bndbox in bndboxes_new:
        color = tuple((255 * np.random.rand(3)))
        if not ('id' in bndbox):
            bndboxes_new[idx]['id'] = last_id
            bndboxes_new[idx]['color'] = color
            last_id += 1
        idx += 1
    # print(who_a_in_b, '||', bndboxes_old, '||', bndboxes_new)
    return [bndboxes_new, last_id]


def draw_bndboxes(frame, bndboxes_new):
    for bndbox in bndboxes_new:
        frame = cv2.rectangle(frame, (bndbox['x1'], bndbox['y1']), (bndbox['x2'], bndbox['y2']), bndbox['color'], 2)
        if 'id' in bndbox:
            frame = cv2.putText(frame, '{}'.format(bndbox['id']), (bndbox['x1'], bndbox['y1'] + 20),
                                cv2.FONT_HERSHEY_COMPLEX, 1, bndbox['color'], 2)
            frame = cv2.putText(frame, '({},{})'.format(bndbox['x1'] + int((bndbox['x2'] - bndbox['x1']) / 2),
                                                        bndbox['y1'] + int((bndbox['y2'] - bndbox['y1']) / 2)),
                                (bndbox['x1'] + int((bndbox['x2'] - bndbox['x1']) / 2),
                                 bndbox['y1'] + int((bndbox['y2'] - bndbox['y1']) / 2)), cv2.FONT_HERSHEY_COMPLEX, 1, bndbox['color'], 2)
            # frame = cv2.putText(frame, '{}'.format(bndbox['x2']-bndbox['x1']), (bndbox['x1'], bndbox['y1'] +10),cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 2)
        # if 'dynamic_th' in bndbox:
        # frame = cv2.putText(frame, '{:.0f}'.format(bndbox['dynamic_th']), (bndbox['x1'], bndbox['y2'] + 10),cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 2)
    return frame


def draw_lines(frame, lines, color):
    for line in lines:
        frame = cv2.line(frame, (line[0], line[1]), (line[2], line[3]), color, 2)
    return frame


def draw_velocities(frame, velocities):
    for velocity in velocities:
        frame = cv2.line(frame, (velocity['x1'], velocity['y1']), (velocity['x2'], velocity['y2']), (255, 0, 0), 2)
    return frame


def crossed_line(frame, bndboxes_old, bndboxes_new, count, line_height):
    color = (255, 0, 0)
    for bndbox_a in bndboxes_new:
        for bndbox_b in bndboxes_old:
            if bndbox_a['id'] == bndbox_b['id']:
                center_y_old = int((bndbox_a['y2'] - bndbox_a['y1']) / 2 + bndbox_a['y1'])
                center_y_new = int((bndbox_b['y2'] - bndbox_b['y1']) / 2 + bndbox_b['y1'])
                if (center_y_old <= line_height) and (center_y_new > line_height):
                    color = (255, 255, 255)
                    count[0] += 1
                elif (center_y_old > line_height) and (center_y_new <= line_height):
                    color = (255, 255, 255)
                    count[1] += 1
    frame = cv2.putText(frame, 'up= {}'.format(count[0]), (10, 30), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
    frame = cv2.putText(frame, 'down= {}'.format(count[1]), (10, 60), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
    return [frame, count, color]


def frame_rotation(frame):
    frame = cv2.transpose(frame)
    frame = cv2.flip(frame, flipCode=+1)
    return frame


def mouseEvent(event, x, y, flags, param):
    global mouseX, mouseY, savePoint, saveArea
    if event == cv2.EVENT_LBUTTONDOWN:
        mouseX, mouseY = x, y
        savePoint = True
    elif event == cv2.EVENT_LBUTTONDBLCLK:
        saveArea = True


def drawAreas(frame, detectionAreas, mode = 0):
    frameCpy = frame.copy()
    for detectionArea in detectionAreas:
        if len(detectionArea) > 1:
            if mode == 0:
                cv2.fillPoly(frameCpy, [np.array(detectionArea, np.int32)], (0, 0, 0))
                cv2.polylines(frameCpy, [np.array(detectionArea, np.int32)], True, (0, 0, 0), thickness=3)
            elif mode == 1 :
                cv2.fillPoly(frameCpy, [np.array(detectionArea, np.int32)], (126, 126, 126))
                cv2.polylines(frameCpy, [np.array(detectionArea, np.int32)], True, (126, 126, 126), thickness=3)
    return frameCpy


def readAreas(frame):
    global mouseX, mouseY, savePoint, saveArea
    windowTitle = 'Please locate detection areas'
    cv2.namedWindow(windowTitle)
    cv2.setMouseCallback(windowTitle, mouseEvent)
    detectionAreas = []
    detectionArea = []
    while (1):
        drawingFrame = frame.copy()
        drawingFrame = drawAreas(drawingFrame, detectionAreas)
        drawingFrame = drawAreas(drawingFrame, [detectionArea])
        cv2.imshow(windowTitle, drawingFrame)
        c = cv2.waitKey(10)
        if c == 27:
            break
        if c & 0xff == ord('c'):
            detectionAreas = []
            detectionArea = []
        if savePoint:
            savePoint = False
            detectionArea.append((mouseX, mouseY))
        if saveArea:
            saveArea = False
            detectionAreas.append(detectionArea)
            detectionArea = []
    return detectionAreas


def update_bkgrnd(frames, frame, frame_bkgrnd, update = True, history = 10):
    if len(frames) <= history:
        if len(frames) == 0:
            frames = np.array([frame])
        else:
            frames = np.append(frames, [frame], axis=0)
        frame_bkgrnd = np.stack((np.mean(frames[:, :, :, 0], 0), np.mean(frames[:, :, :, 1], 0), np.mean(frames[:, :, :, 2], 0)), axis=2)
        frame_bkgrnd = np.array(frame_bkgrnd, dtype='uint8')
        # frame_bkgrnd = normalization(frame_bkgrnd)
    else:
        if update[1]:
            np.delete(frames, 0)
            frames = np.append(frames, [frame], axis=0)

        if update[0]:
            frame_bkgrnd = np.stack((np.mean(frames[:, :, :, 0], 0), np.mean(frames[:, :, :, 1], 0), np.mean(frames[:, :, :, 2], 0)), axis=2)
            frame_bkgrnd = np.array(frame_bkgrnd, dtype='uint8')
            # frame_bkgrnd = normalization(frame_bkgrnd)
    return [frames, frame_bkgrnd]


#-----//-----//-----//-----//-----//-----/configuration/-----//-----//-----//-----//-----
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_104704_105710.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_105710_110716.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_111722_112730.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_112730_113738.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_113738_114748.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_115800_120808.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_124839_125845.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_130851_131857.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_133910_134916.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_135922_140929.avi'
file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_143949_144956.avi' #variação de luz
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_144956_150003.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_151012_152021.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_143949_144956.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_143949_144956.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Cam_porta/P180406_143949_144956.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/out5.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/People_sample_4.mp4'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/People_sample_1.avi'
# file_path = '/home/vinicius/PycharmProjects/videos_p_testes/Traffic_sample_3.mp4'
# file_path = "rtsp://admin:admin@192.168.1.132:554/12"


window_name = 'frame'
threshold_detection = 2  # 0%~100%
threshold_intensity = 100  # 0~255
threshold_tracking = 0.1  # 0~1
threshold_multi = 47  # 0~100%
line_height = 50  # 0%~100%
sampling_period = 5 #the period that the frames used for the mean image will be updated with a new frame
history = 10 #how many frames will be used for the mean image
save_video = 'f' #self explanatory
save_frames = 't' #self explanatory
save_csv = 'f' #self explanatory
portrait = 'f' #rotate to portrait mode
norm = 't' #normalization
mog = True #use MOG2 function
absdiff = True #use a subtraction with a mean image
#-----//-----//-----//-----//-----//-----/end-configuration/-----//-----//-----//-----//-----


#-----//-----//-----//-----//-----//-----/variables, etc.../-----//-----//-----//-----//-----
dt = datetime.now(timezone('Brazil/East'))
date = '{}_{}_{}'.format(dt.date().day, dt.date().month, dt.date().year)
time = '{}_{}_{}'.format(dt.time().hour, dt.time().minute, dt.time().second)
save_frames_path = 'outputs/frames-{}-{}/'.format(date, time)


cap = cv2.VideoCapture(file_path)
fgbg = cv2.createBackgroundSubtractorMOG2()#history=100)#, varThreshold=10)
# fgbg = cv2.createBackgroundSubtractorKNN()
kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
kernel2 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
'''
size = 15
middle = 5
kernel2 = np.hstack((np.zeros((size,int((size-middle)/2)),dtype='uint8'),
                     np.ones((size,middle),dtype='uint8'),
                     np.zeros((size,int((size-middle)/2)),dtype='uint8')))
'''
if not (os.path.isdir('outputs')):
    os.mkdir('outputs')


frame_number = 0
count = [0, 0]
counted_ids = []
bndboxes_old = []
last_id = 0
last_now = {'frame_number': 0, 'second': 0}
color = (255, 0, 0)
fps = 0


frame_bkgrnd = []
frames = []
white = []
seconds = [0]*2
seconds[0] = tm.time()
update = [False]*2
#-----//-----//-----//-----//-----//-----/end-variables, etc.../-----//-----//-----//-----//-----

#-----//-----//-----//-----//-----//-----/algorithm loop/-----//-----//-----//-----//-----
while (1):
    ret, frame = cap.read()
    key_pressed = cv2.waitKey(1)
    if (not ret) or (key_pressed == 27):
        break


    if portrait == 't':
        frame = frame_rotation(frame)
    frame_original = frame.copy()
    if norm == 't':
        frame = normalization(frame)


    if frame_number == 0:
        # area_del = readAreas(frame_original)
        area_del = [[(90, 1), (218, 132), (214, 248), (99, 257), (342, 276), (565, 251), (444, 243), (436, 129), (557, 1), (632, 74), (639, 103), (639, 349), (1, 351), (2, 231), (15, 104), (56, 3), (56, 3)]]
        print(area_del)
        height, width, _ = np.shape(frame)
        threshold_detection = int(threshold_detection * height * width / 100)
        threshold_multi = int(threshold_multi * width / 100)
        line_height = int(height - height * line_height / 100)
        if save_video == 't':
            fourcc = cv2.VideoWriter_fourcc(*'XVID')
            out = cv2.VideoWriter('outputs/' + 'out-{}-{}.avi'.format(date, time), fourcc, 24.0, (width, height))
        print('threshold detection area={} || threshold multiple detection={}'.format(threshold_detection, threshold_multi))

    # -----//-----//-----//-----//-----//-----/important part/-----//-----//-----//-----//-----
    frames, frame_bkgrnd = update_bkgrnd(frames, drawAreas(frame.copy(), area_del), frame_bkgrnd, update=update, history=history)
    frame_del_areas = drawAreas(frame, area_del)
    seconds[1] = tm.time()
    frame_processed, pre_processing, update, white = image_processing(frame_del_areas, frame_bkgrnd, white, seconds, mog, absdiff=absdiff, filled=True, kernel=kernel, kernel2=kernel2, history=history, sampling_period=sampling_period)
    bndboxes_new = detections(frame_processed, threshold_detection, threshold_multi)
    bndboxes_new, last_id = tracking(bndboxes_old, bndboxes_new, threshold_tracking, last_id)
    velocities = calc_velocities(bndboxes_old, bndboxes_new)
    frame_original = draw_bndboxes(frame_original, bndboxes_new)
    frame_original = draw_velocities(frame_original, velocities)
    frame_original, count, color = crossed_line(frame_original, bndboxes_old, bndboxes_new, count, line_height)
    frame_original = draw_lines(frame_original, [[0, line_height, width, line_height]], color)
    frame_processed = cv2.cvtColor(frame_processed, cv2.COLOR_GRAY2BGR)
    frame_processed = draw_bndboxes(frame_processed, bndboxes_new)
    frame_processed = drawAreas(frame_processed, area_del, mode=1)
    # -----//-----//-----//-----//-----//-----/end-important part/-----//-----//-----//-----//-----

    if save_video == 't':
        out.write(frame_original)
    frame = np.hstack((frame_original, frame_processed, pre_processing))
    if save_frames == 't' and len(bndboxes_old) >= 1: # save frames
        if not (os.path.isdir(save_frames_path)):
            os.mkdir(save_frames_path)
        cv2.imwrite(save_frames_path + '{}.jpg'.format(frame_number), frame)
    now = datetime.now(timezone('Brazil/East'))
    if save_csv == 't':  # SAVE CSV
        if frame_number == 0:
            csv_file = 'outputs/{}-{}.csv'.format(date, time)
            f = open(csv_file, 'w')
            writer = csv.writer(f, delimiter=',')
            writer.writerow(['frame_id', 'time_stamp', 'count_up', 'count_down'])
            f.flush()
        elif len(bndboxes_old) >= 1:
            writer.writerow(
                [frame_number, '{}:{}:{}'.format(dt.time().hour, dt.time().minute, dt.time().second), count[1],
                    count[0]])
    if now.time().second != last_now['second']:  # SHOW FPS
        fps = frame_number - last_now['frame_number']
        last_now = {'frame_number': frame_number, 'second': now.time().second}
        if frame_number % 100:
            print('FPS= ', fps)
    frame_original = cv2.putText(frame_original, '{}FPS'.format(fps), (width - 110, 30), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)


    # cv2.imshow(window_name, frame)
    bndboxes_old = bndboxes_new
    frame_number += 1
#-----//-----//-----//-----//-----//-----/end-algorithm loop/-----//-----//-----//-----//-----

cap.release()
if save_video == 't':
    out.release()
cv2.destroyAllWindows()
