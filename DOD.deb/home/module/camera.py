from __future__ import print_function
from picamera import PiCamera
from picamera.array import PiRGBArray
from threading import Thread
from datetime import datetime
from imutils.video.pivideostream import PiVideoStream
from imutils.video import FPS
import imutils
import time
import cv2


class FrameInjector(Thread):
	def __init__(self):
		super().__init__()
		self.buffer = []

	def fetch_buffer(self, _size):
		ret = self.buffer[:]
		self.buffer = self.buffer[_size:]
		#print("Chamei Clear")
		self.buffer.clear()

		return ret
		
	def run(self):
		vs = PiVideoStream().start()
		time.sleep(1)
		#fps = FPS().start()
		while 1:
			frame = vs.read()
#			print(str(type(frame)))
			frame = imutils.resize(frame, width=640)
			#print("Len",len(self.buffer))
			if not self.buffer:
				self.buffer.append(frame)
				continue
			frame_old = self.buffer[-1]
			frame_old = cv2.cvtColor(frame_old, cv2.COLOR_BGR2GRAY)
			frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
			res = cv2.matchTemplate(frame_gray, frame_old, cv2.TM_CCOEFF_NORMED)
			#print("RES", res)
			if res[0][0] >= 0.9999: continue
			self.buffer.append(frame)

			time.sleep(0.1)
			#print("Appended frame!")
