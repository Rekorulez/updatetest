source activate dod-enviroment
cd /home/pi/main
python main.py
