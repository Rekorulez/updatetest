bash ./pi/apSwitch/stopAP.sh
