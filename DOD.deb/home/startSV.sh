bash ./pi/local-server/startServer.sh
