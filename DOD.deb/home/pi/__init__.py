'''
	Essa pasta contem arquivos relacionados ao gerenciamento do dispositivo, como credenciais de Wifi e interacao com o usuario
'''
