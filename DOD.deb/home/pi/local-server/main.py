from flask import Flask, render_template, request
app = Flask(__name__)

def update_password(ssid, pwd):
	print('UPDATING...')
	import os
	os.system('sudo ./update_wifi.sh ' + str(ssid) +' ' + str(pwd))
	print('UPDATING...')
	os.system('pwd')
	os.system('./stopServer.sh')

@app.route('/')
def setup():
   return render_template('student.html')

@app.route('/result',methods = ['POST', 'GET'])
def result():
   if request.method == 'POST':
      result = request.form
      update_password(result['ssid'], result['senha'])
      return render_template("result.html",result = result)

if __name__ == '__main__':
   app.run(debug = True, host = '0.0.0.0', port = 5000)
