#!/bin/bash
cd ..
cd apSwitch
./stopAP.sh
