#!/bin/bash
#sudo su
echo $1
echo $2
echo 1 | wpa_passphrase $1 $2 >>  /etc/wpa_supplicant/wpa_supplicant.conf
wpa_cli -i wlan0 reconfigure
echo "Updated wifi"
exit
