#!/bin/bash
#sudo wget -q https://raw.githubusercontent.com/xeenin/dodAP/master/installers/uninstall.sh -O ./tmp/dodpiu
#sudo chmod +x ./tmp/dodpiu 
./tmp/dodpiu
sudo reboot -h now
