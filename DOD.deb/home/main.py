import os

def update_estado(novo_estado):
	print("Atualizando estado da maquina para", novo_estado)
	open('./.wificonf', 'w').write(novo_estado)

estado = open('./.wificonf', 'r').read().replace('\n', '')
if estado == '0':
	update_estado('1')
	os.system('./startAP.sh')
elif estado == '1':
	update_estado('2')
	os.system('./startSV.sh')
elif estado == '2':
	update_estado('3')
	os.system('./stopAP.sh')
elif estado == '3':
	os.system('./startBS.sh')
