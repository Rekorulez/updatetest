# bs-tmp
Esse é o repositorio temporario para o algoritmo Backgroud subtraction rodando no raspberry pi, embarcado

-- main.py

    Este arquivo busca ser uma maquina de estados, onde estaria reservado o modo de operacao dos arquivos. Pode ser alterado

-- .config

    Este arquivo contem configuracoes iniciais, como ID do raspberry(para ser usado no banco). Pode ser alterado

-- .state

    Este arquivo indica o estado atual da maquina com IDs, sendo cada ID atribuido de maneira sequencial a cada estado. Pode ser 
    alterado

-- .wificonf

    Este arquivo indica se o wifi precisa ser configurado. Pode ser alterado

-- change_state_btt.py

    Este script altera o estado  do wifi quando o botao é clicado, ou seja, esse script se responsabiliza por alterar o rasp do 
    modo wifi para o modo roteador

-- *.sh

    Esses placeholders para teste

    

-- module/

    Essa pasta contem os arquivos necessarios para rodar o modulo

    -- module/main.py

        Roda o backgroud subtraction ja conectado ao banco e medindo hardware

-- pi/

    Essa pasta contem os arquivos necessarios para gerenciamento do estado do raspberry( modo wifi vs modo access point)

    pi/apSwitch/

      Essa pasta contem os arquivos responsaveis pela troca de modo entre wifi e roteador

        pi/apSwitch/startAP.sh

            Este script inicia o modo roteador e desliga o modo wifi

        pi/apSwitch/stopAP.py

            Este scrip inicia o modo wifi e desliga o modo roteador

        pi/apSwitch/wrapper.py

            É um wrapper que chama os scripts localmente. A vantagem de usar isso é que podemos importar dentro do python

    pi/local-server

        Essa pasta contem os arquivos necessarios para rodar o servidor local que configura o wifi

        pi/local-server/startServer.sh

            Este arquivo abre o servidor na porta 5000 e no IP local

        pi/local-server/stopServer.sh

            Este arquivo é um wrapper para chamar stopAP.sh
