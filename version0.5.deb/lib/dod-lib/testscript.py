import time

while 1:
    print('English')
    print('Moth*******')
    print('DO')
    print('YOU')
    print('SPEAK IT?')
    time.sleep(5)
