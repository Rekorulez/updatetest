echo "Running startAP"
bash ./pi/apSwitch/startAP.sh
