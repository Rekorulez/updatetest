
class DatabaseThread(Thread):
	def __init__(self):
		super().__init__()
		self.buffer = []

	def add_event(self, op, t, cliente, loja): #TODO: Limpar e melhorar isso, tornar camera generica
		if op == 'up': op = 'entry'
		else: op = 'exit'
		timestamp = (t - datetime(1970, 1, 1)).total_seconds()
		data = {'event': op, 'timestamp': timestamp, 'cameraId':'porta'}
		self.buffer.append(data)
	def run(self):
		while 1:
			if not self.buffer: continue
			b = self.buffer[:]
			self.buffer.clear()
			for i in b:
				db.child('analytics').child(cliente).child(loja).child('events').push(i)
				print("BOOOOORA QUE DEU BOA!")
