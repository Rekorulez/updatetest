import cv2
import numpy as np
from datetime import datetime
from pytz import timezone
import time as tm
import gc
#from DODFunction.api import write_to_db
#from DODFunction.utilidades import get_timeNow


class count_people():

    def __init__(self, mog = True, absdiff = False, norm = False):
        self.threshold_detection = 2  # 0%~100%
        self.threshold_intensity = 100  # 0~255
        self.threshold_tracking = 0.1  # 0~1
        self.threshold_multi = 47  # 0~100%
        self.line_height = 50  # 0%~100%
        self.sampling_period = 5 #the period that the frames used for the mean image will be updated with a new frame
        self.history = 10 #how many frames will be used for the mean image
        self.portrait = 'f' #rotate to portrait mode
        self.norm = norm #normalization
        self.mog = mog #use MOG2 function
        self.absdiff = absdiff #use a subtraction with a mean image
        self.dt = datetime.now(timezone('Brazil/East'))
        self.date = '{}_{}_{}'.format(self.dt.date().day, self.dt.date().month, self.dt.date().year)
        self.time = '{}_{}_{}'.format(self.dt.time().hour, self.dt.time().minute, self.dt.time().second)
        self.fgbg = cv2.createBackgroundSubtractorMOG2()#history=100)#, varThreshold=10)
        self.kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        self.kernel2 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
        self.frame_number = 0
        self.count = [0, 0]
        self.bndboxes_old = []
        self.bndboxes_new = []
        self.last_id = 0
        self.last_now = {'frame_number': 0, 'second': 0}
        self.color = (255, 0, 0)
        self.frame_bkgrnd = []
        self.frames = []
        self.white = []
        self.seconds = [0]*2
        self.seconds[0] = tm.time()
        self.update = [False]*2
        self.area_del = []
        self.height, self.width = [0, 0]
        self.saveArea = self.savePoint = False
        self.mouseX = self.mouseY = 0
        self.events = []
        self.frame_processed = np.array([])
        self.frame_nprocessed = np.array([])

    def iou(self, x1_a, y1_a, x2_a, y2_a, x1_b, y1_b, x2_b, y2_b):  # retorn the intersection
        w_a = x2_a - x1_a
        w_b = x2_b - x1_b
        if x1_b <= x1_a and x2_b > x1_a and x2_a > x2_b:
            w_i = x2_b - x1_a
        elif x1_b < x2_a and x2_b >= x2_a and x1_a < x1_b:
            w_i = x2_a - x1_b
        elif x1_b > x1_a and x2_b < x2_a:
            w_i = w_b
        elif x1_b <= x1_a and x2_b >= x2_a:
            w_i = w_a
        else:
            w_i = 0
        h_a = y2_a - y1_a
        h_b = y2_b - y1_b
        if y1_b <= y1_a and y2_b > y1_a and y2_a > y2_b:
            h_i = y2_b - y1_a
        elif y1_b < y2_a and y2_b >= y2_a and y1_a < y1_b:
            h_i = y2_a - y1_b
        elif y1_b > y1_a and y2_b < y2_a:
            h_i = h_b
        elif y1_b <= y1_a and y2_b >= y2_a:
            h_i = h_a
        else:
            h_i = 0
        A_a = w_a * h_a
        A_b = w_b * h_b
        A_i = w_i * h_i  # intersection
        return A_i / (A_a + A_b - A_i + 1e-6)

    def normalization(self, Frame):
        frame_sum = (Frame.sum(2) + 1e-5)#cv2.add(Frame[:, :, 2], cv2.add(Frame[:, :, 0], Frame[:, :, 1]))
        Frame[:, :, 0] = Frame[:, :, 0] / frame_sum*255
        Frame[:, :, 1] = Frame[:, :, 1] / frame_sum*255
        Frame[:, :, 2] = Frame[:, :, 2] / frame_sum*255
        return Frame

    def image_processing(self, Frame, frame_bkgrnd, update, white, seconds, mog, absdiff=False, filled=False, kernel=None, kernel2=None, sampling_period=5, history=10):

        Frame = cv2.GaussianBlur(Frame, (7,7), 0)
        pre_processing = Frame.copy()
        if mog and absdiff:
            frame_fgbg = self.fgbg.apply(Frame)
            _, frame_fgbg = cv2.threshold(frame_fgbg, 128, 255, cv2.THRESH_BINARY)
            Frame[:, :, 0] = cv2.absdiff(Frame[:, :, 0], frame_bkgrnd[:, :, 0])
            Frame[:, :, 1] = cv2.absdiff(Frame[:, :, 1], frame_bkgrnd[:, :, 1])
            Frame[:, :, 2] = cv2.absdiff(Frame[:, :, 2], frame_bkgrnd[:, :, 2])
            Frame = cv2.cvtColor(Frame, cv2.COLOR_BGR2GRAY)
            _, Frame = cv2.threshold(Frame, 50, 255, cv2.THRESH_BINARY)
            Frame = cv2.erode(Frame, kernel)
            Frame = cv2.add(Frame, frame_fgbg)
        elif mog:
            Frame = self.fgbg.apply(Frame)
            _, Frame = cv2.threshold(Frame, 128, 255, cv2.THRESH_BINARY)
        elif absdiff:
            Frame[:, :, 0] = cv2.absdiff(Frame[:, :, 0], frame_bkgrnd[:, :, 0])
            Frame[:, :, 1] = cv2.absdiff(Frame[:, :, 1], frame_bkgrnd[:, :, 1])
            Frame[:, :, 2] = cv2.absdiff(Frame[:, :, 2], frame_bkgrnd[:, :, 2])
            Frame = cv2.cvtColor(Frame, cv2.COLOR_BGR2GRAY)
            _, Frame = cv2.threshold(Frame, 50, 255, cv2.THRESH_BINARY)
        if filled:
            _, Contours, _ = cv2.findContours(Frame, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE);
            cv2.drawContours(Frame, Contours, -1, (255,255,255), thickness=cv2.FILLED);


        run = False
        update[0] = False
        update[1] = False
        if len(white) == 0 or seconds[1] - seconds[0] >= sampling_period:
            update[1] = True
            white.append(np.sum((cv2.threshold(Frame.copy(), 127, 1, cv2.THRESH_BINARY)[1])))
            seconds[0] = seconds[1]
            run = True
        if run:
            if np.abs((white[-1]-np.mean(white))) < 1000:
                update[0] = True
        if len(white) > history:
            del white[0]
        return [Frame, pre_processing, update, white]


    def detections(self, frame, threshold_detection, threshold_multi):
        coords = []
        bndboxes = []
        _, Contours, _ = cv2.findContours(frame, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for i in range(len(Contours)):
            coords.append(cv2.boundingRect(Contours[i]))
            if coords[i][2] * coords[i][3] >= threshold_detection:
                x1 = coords[i][0]
                y1 = coords[i][1]
                x2 = coords[i][0] + coords[i][2]
                y2 = coords[i][1] + coords[i][3]
                iter = int((x2 - x1) / threshold_multi)
                if iter >= 1:
                    delta_x = int((x2 - x1) / (iter + 1))
                    for i in range(iter + 1):
                        bndboxes.append({'x1': x1 + delta_x * i, 'y1': y1, 'x2': x1 + delta_x * (i + 1), 'y2': y2})
                else:
                    bndboxes.append({'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2})
        return bndboxes


    def calc_velocity(self, x1_a, y1_a, x2_a, y2_a, x1_b, y1_b, x2_b, y2_b):
        l = 80
        vector_1 = [(x1_b - x1_a), (y1_b - y1_a)]
        vector_2 = [(x2_b - x2_a), (y2_b - y2_a)]
        vector = [vector_1[0] + vector_2[0], vector_1[1] + vector_2[1]]
        speed = (vector[0] ** 2 + vector[1] ** 2) ** 0.5 + 1e-5
        vector = [int(vector[0] * l / speed), int(vector[1] * l / speed)]

        center_x = int((x2_b - x1_b) / 2) + x1_b
        center_y = int((y2_b - y1_b) / 2) + y1_b

        velocity_vector = {'x1': center_x, 'y1': center_y, 'x2': vector[0] + center_x, 'y2': vector[1] + center_y}
        return velocity_vector


    def calc_velocities(self, bndboxes_old, bndboxes_new):
        velocity_vectors = []
        for bndbox_a in bndboxes_old:
            for bndbox_b in bndboxes_new:
                if bndbox_a['id'] == bndbox_b['id']:
                    x1_a = bndbox_a['x1']
                    y1_a = bndbox_a['y1']
                    x2_a = bndbox_a['x2']
                    y2_a = bndbox_a['y2']
                    x1_b = bndbox_b['x1']
                    y1_b = bndbox_b['y1']
                    x2_b = bndbox_b['x2']
                    y2_b = bndbox_b['y2']
                    velocity_vectors.append(self.calc_velocity(x1_a, y1_a, x2_a, y2_a, x1_b, y1_b, x2_b, y2_b))
                    velocity_vectors[-1]['id'] = bndbox_a['id']
        return velocity_vectors


    def find_a_in_b(self, bndboxes_old, bndboxes_new, threshold_tracking):
        best_IOU = [0] * len(bndboxes_old)
        who_a_in_b = []
        idx_a = 0
        for bndbox_a in bndboxes_old:
            x1_a = bndbox_a['x1']
            y1_a = bndbox_a['y1']
            x2_a = bndbox_a['x2']
            y2_a = bndbox_a['y2']
            idx_b = 0
            who_a_in_b.append({'a_is_in_b': False, 'index_a': idx_a, 'index_b': None})
            for bndbox_b in bndboxes_new:
                x1_b = bndbox_b['x1']
                y1_b = bndbox_b['y1']
                x2_b = bndbox_b['x2']
                y2_b = bndbox_b['y2']
                IOU = self.iou(x1_a, y1_a, x2_a, y2_a, x1_b, y1_b, x2_b, y2_b)
                if IOU >= best_IOU[idx_a]:
                    best_IOU[idx_a] = IOU
                    if best_IOU[idx_a] >= threshold_tracking:
                        who_a_in_b[idx_a] = {'a_is_in_b': True, 'index_a': idx_a, 'index_b': idx_b}
                idx_b += 1
            idx_a += 1
        return who_a_in_b


    def tracking(self, bndboxes_old, bndboxes_new, threshold_tracking, last_id):
        who_a_in_b = self.find_a_in_b(bndboxes_old, bndboxes_new, threshold_tracking)
        for a in who_a_in_b:
            color = tuple((255 * np.random.rand(3)))
            if a['a_is_in_b']:
                if not ('id' in bndboxes_old[a['index_a']]):
                    bndboxes_old[a['index_a']]['id'] = last_id
                    bndboxes_new[a['index_b']]['id'] = last_id
                    bndboxes_old[a['index_a']]['color'] = color
                    bndboxes_new[a['index_b']]['color'] = color
                    last_id += 1
                else:
                    bndboxes_new[a['index_b']]['id'] = bndboxes_old[a['index_a']]['id']
                    bndboxes_new[a['index_b']]['color'] = bndboxes_old[a['index_a']]['color']
            # else:
            #     bndboxes_new.append(bndboxes_old[a['index_a']])
            #     if not ('lost' in bndboxes_new[-1]):
            #         bndboxes_new[-1]['lost'] = 0
            #     elif bndboxes_new[-1]['lost'] >= 2:
            #         del bndboxes_new[-1]
            #     else:
            #         bndboxes_new[-1]['lost'] += 1

        idx = 0
        for bndbox in bndboxes_new:
            color = tuple((255 * np.random.rand(3)))
            if not ('id' in bndbox):
                bndboxes_new[idx]['id'] = last_id
                bndboxes_new[idx]['color'] = color
                last_id += 1
            idx += 1
        return [bndboxes_new, last_id]


    def draw_bndboxes(self, frame, bndboxes_new):
        for bndbox in bndboxes_new:
            frame = cv2.rectangle(frame, (bndbox['x1'], bndbox['y1']), (bndbox['x2'], bndbox['y2']), bndbox['color'], 2)
            # if 'id' in bndbox:
            #     frame = cv2.putText(frame, '{}'.format(bndbox['id']), (bndbox['x1'], bndbox['y1'] + 20),
            #                         cv2.FONT_HERSHEY_COMPLEX, 1, bndbox['color'], 2)
            #     frame = cv2.putText(frame, '({},{})'.format(bndbox['x1'] + int((bndbox['x2'] - bndbox['x1']) / 2),
            #                                                 bndbox['y1'] + int((bndbox['y2'] - bndbox['y1']) / 2)),
            #                         (bndbox['x1'] + int((bndbox['x2'] - bndbox['x1']) / 2),
            #                          bndbox['y1'] + int((bndbox['y2'] - bndbox['y1']) / 2)), cv2.FONT_HERSHEY_COMPLEX, 1, bndbox['color'], 2)
                # frame = cv2.putText(frame, '{}'.format(bndbox['x2']-bndbox['x1']), (bndbox['x1'], bndbox['y1'] +10),cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 2)
            # if 'dynamic_th' in bndbox:
            # frame = cv2.putText(frame, '{:.0f}'.format(bndbox['dynamic_th']), (bndbox['x1'], bndbox['y2'] + 10),cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 2)
        return frame


    def draw_lines(self, frame, lines, color):
        for line in lines:
            frame = cv2.line(frame, (line[0], line[1]), (line[2], line[3]), color, 2)
        return frame


    def draw_velocities(self, frame, velocities):
        for velocity in velocities:
            frame = cv2.line(frame, (velocity['x1'], velocity['y1']), (velocity['x2'], velocity['y2']), (255, 0, 0), 2)
        return frame


    def crossed_line(self, frame):
        self.color = (255, 0, 0)
        for bndbox_a in self.bndboxes_new:
            for bndbox_b in self.bndboxes_old:
                if bndbox_a['id'] == bndbox_b['id']:
                    center_y_old = int((bndbox_a['y2'] - bndbox_a['y1']) / 2 + bndbox_a['y1'])
                    center_y_new = int((bndbox_b['y2'] - bndbox_b['y1']) / 2 + bndbox_b['y1'])
                    if (center_y_old <= self.line_height) and (center_y_new > self.line_height):
                        self.color = (255, 255, 255)
                        self.count[0] += 1
                        time_stamp = '{}:{}:{}'.format(datetime.now(timezone('Brazil/East')).hour,datetime.now(timezone('Brazil/East')).minute,datetime.now(timezone('Brazil/East')).second)
                        coords = [bndbox_b['x1'], bndbox_b['y1'], bndbox_b['x2'], bndbox_b['y2']]
                        self.events.append({'time_stamp':time_stamp, 'coords':coords, 'id':bndbox_b['id'], 'direction':'up'})
                        # write_to_db(get_timeNow(), 'e',  self.store_name, 'count_people_module', 'entrada', 1)
                        print('detectei')
                    elif (center_y_old > self.line_height) and (center_y_new <= self.line_height):
                        self.color = (255, 255, 255)
                        self.count[1] += 1
                        time_stamp = '{}:{}:{}'.format(datetime.now(timezone('Brazil/East')).hour,datetime.now(timezone('Brazil/East')).minute,datetime.now(timezone('Brazil/East')).second)
                        coords = [bndbox_b['x1'], bndbox_b['y1'], bndbox_b['x2'], bndbox_b['y2']]
                        self.events.append({'time_stamp': time_stamp, 'coords': coords, 'id': bndbox_b['id'], 'direction':'down'})
                        # write_to_db(get_timeNow(), 's', self.store_name, 'count_people_module', 'entrada', 1)
                        print('detectei')
        # frame = cv2.putText(frame, 'Entrou= {}'.format(self.count[0]), (10, 30), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
        # frame = cv2.putText(frame, 'Saiu= {}'.format(self.count[1]), (10, 60), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 0, 255), 2)
        frame = cv2.putText(frame, '{}'.format(self.count[0]), (530, 80), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
        # frame = cv2.putText(frame, '{}'.format(self.count[1]), (580, 60), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
        # cv2.imshow(self.store_name, frame)
        return frame


    def frame_rotation(self, frame):
        frame = cv2.transpose(frame)
        frame = cv2.flip(frame, flipCode=+1)
        return frame


    def mouseEvent(self, event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN:
            self.mouseX, self.mouseY = x, y
            self.savePoint = True
        elif event == cv2.EVENT_LBUTTONDBLCLK:
            self.saveArea = True


    def drawAreas(self, frame, detectionAreas, mode = 0):
        frameCpy = frame.copy()
        for detectionArea in detectionAreas:
            if len(detectionArea) > 1:
                if mode == 0:
                    cv2.fillPoly(frameCpy, [np.array(detectionArea, np.int32)], (0, 0, 0))
                    cv2.polylines(frameCpy, [np.array(detectionArea, np.int32)], True, (0, 0, 0), thickness=3)
                elif mode == 1 :
                    cv2.fillPoly(frameCpy, [np.array(detectionArea, np.int32)], (126, 126, 126))
                    cv2.polylines(frameCpy, [np.array(detectionArea, np.int32)], True, (126, 126, 126), thickness=3)
        return frameCpy


    def readAreas(self, frame):
        windowTitle = 'Please locate detection areas'
        cv2.namedWindow(windowTitle)
        cv2.setMouseCallback(windowTitle, self.mouseEvent())
        detectionAreas = []
        detectionArea = []
        while (1):
            drawingFrame = frame.copy()
            drawingFrame = self.drawAreas(drawingFrame, detectionAreas)
            drawingFrame = self.drawAreas(drawingFrame, [detectionArea])
            #cv2.imshow(windowTitle, drawingFrame)
            c = cv2.waitKey(10)
            if c == 27:
                break
            if c & 0xff == ord('c'):
                detectionAreas = []
                detectionArea = []
            if self.savePoint:
                self.savePoint = False
                detectionArea.append((self.mouseX, self.mouseY))
            if self.saveArea:
                self.saveArea = False
                detectionAreas.append(detectionArea)
                detectionArea = []
        return detectionAreas


    def update_bkgrnd(self, frames, frame, frame_bkgrnd, update, history = 10):
        if len(frames) <= history:
            if len(frames) == 0:
                frames = np.array([frame])
            else:
                frames = np.append(frames, [frame], axis=0)
            frame_bkgrnd = np.stack((np.mean(frames[:, :, :, 0], 0), np.mean(frames[:, :, :, 1], 0), np.mean(frames[:, :, :, 2], 0)), axis=2)
            frame_bkgrnd = np.array(frame_bkgrnd, dtype='uint8')
        else:
            if update[1]:
                frames = np.delete(frames, 0, 0)
                frames = np.append(frames, [frame], axis=0)

            if update[0]:
                frame_bkgrnd = np.stack((np.mean(frames[:, :, :, 0], 0), np.mean(frames[:, :, :, 1], 0), np.mean(frames[:, :, :, 2], 0)), axis=2)
                frame_bkgrnd = np.array(frame_bkgrnd, dtype='uint8')
        return [frames, frame_bkgrnd]


    def principal(self, frame):
        self.events = []
        if self.portrait == 't':
            frame = self.frame_rotation(frame)
        frame_original = frame.copy()

        if self.norm:
            frame = self.normalization(frame)

        if self.frame_number == 0:
            # self.area_del = self.readAreas(frame_original)
            # self.area_del = [[(90, 1), (218, 132), (214, 248), (99, 257), (342, 276), (565, 251), (444, 243), (436, 129), (557, 1), (632, 74), (639, 103), (639, 349), (1, 351), (2, 231), (15, 104), (56, 3), (56, 3)]]
            self.area_del = []
            self.height, self.width, _ = frame.shape
            self.threshold_detection = int(self.threshold_detection * self.height * self.width / 100)
            self.threshold_multi = int(self.threshold_multi * self.width / 100)
            self.line_height = int(self.height - self.height * self.line_height / 100)
            # print('threshold detection area={} || threshold multiple detection={}'.format(self.threshold_detection, self.threshold_multi))


        self.frames, self.frame_bkgrnd = self.update_bkgrnd(self.frames, self.drawAreas(frame.copy(), self.area_del), self.frame_bkgrnd, update=self.update, history=self.history)
        frame_del_areas = self.drawAreas(frame, self.area_del)
        self.seconds[1] = tm.time()
        frame_processed, pre_processing, self.update, self.white = self.image_processing(frame_del_areas, self.frame_bkgrnd, self.update, self.white, self.seconds, self.mog, absdiff=self.absdiff, filled=True, kernel=self.kernel, kernel2=self.kernel2, history=self.history, sampling_period=self.sampling_period)
        self.bndboxes_new = self.detections(frame_processed, self.threshold_detection, self.threshold_multi)
        self.bndboxes_new, self.last_id = self.tracking(self.bndboxes_old, self.bndboxes_new, self.threshold_tracking, self.last_id)
        velocities = self.calc_velocities(self.bndboxes_old, self.bndboxes_new)
        frame_original = self.draw_bndboxes(frame_original, self.bndboxes_new)
        frame_original = self.draw_velocities(frame_original, velocities)
        frame_original= self.crossed_line(frame_original)
        frame_original = self.draw_lines(frame_original, [[0, self.line_height, self.width, self.line_height]], self.color)
        frame_processed = cv2.cvtColor(frame_processed, cv2.COLOR_GRAY2BGR)
        frame_processed = self.draw_bndboxes(frame_processed, self.bndboxes_new)
        frame_processed = self.drawAreas(frame_processed, self.area_del, mode=1)

        frame = np.hstack((frame_original, frame_processed, pre_processing))
        now = datetime.now(timezone('Brazil/East'))
        self.bndboxes_old = self.bndboxes_new
        self.frame_number += 1
        if self.frame_number % 100 == 0:
            n = gc.collect()
        self.frame_processed = frame
        if self.events: cv2.imwrite('vinao.jpg', self.frame_processed)
        # self.frame_nprocessed = frame_original
        # cv2.imshow('qweqwe', frame)
        #cv2.imshow('sadasds', frame)
        # cv2.waitKey(27)
        # print('kkk')
        return self.events
