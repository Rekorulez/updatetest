#from DODFunction.controller import LiveController
from datetime import datetime
from CountPeople.main_module import count_people
from pyrebase.pyrebase.pyrebase import initialize_app
from oauth2client.service_account import ServiceAccountCredentials
import cv2
import os
from picamera import PiCamera
from picamera.array import PiRGBArray
import RPi.GPIO as GPIO
from time import sleep
from camera import FrameInjector
from threading import Thread
from multiprocessing import Process, Queue
'''
It is necessary to have psutil and GPUtil installed, to install them use:
conda install psutil or pip install psutil
pip install GPUtil
pip install RPi.gpio <- hardware library to LEDs work 
'''

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(2,GPIO.OUT)
GPIO.setup(3,GPIO.OUT)

class hardware_usage():
    import psutil
    # import GPUtil
    import time
    import csv
    import numpy as np
    import os
    from datetime import datetime
    from threading import Thread


    def __init__(self, interval = 1):
        print('monitoring resources and saving')
        self.check_dir('hardware_usage/')
        # GPUs = self.GPUtil.getGPUs()
        self.interval = interval
        self.hour = self.datetime.now().hour
        self.header = ['time_stamp']
        self.header += list(map(lambda core: 'CPU_%d_usage'%core, list(range(self.psutil.cpu_count()))))
        self.header += ['memory_usage']
        # self.header += list(map(lambda core: 'GPU_%d_usage'%core, list(range(len(GPUs)))))
        # self.header += list(map(lambda core: 'GPU_%d_memory_usage' % core, list(range(len(GPUs)))))
        try:
            time = str(self.datetime.now(timezone('Brazil/East')))[:19].replace(' ', '_').replace(':', '_')
        except:
            time = str(self.datetime.now())[:19].replace(' ', '_').replace(':', '_')
        f = open('hardware_usage/%s.csv' % time, 'w')
        self.csv_file = self.csv.writer(f, delimiter=',')
        self.csv_file.writerow(self.header)
        f.flush()


    def get_hardware_usage(self):
            #print("RUNNING")
            # GPUs = self.GPUtil.getGPUs()
            # gpus_load = list(map(lambda gpu: self.np.uint8(gpu.load*100), GPUs))
            # gpus_memory = list(map(lambda gpu: self.np.uint32(gpu.memoryUsed), GPUs))
            time = str(self.datetime.now())[:19]
            hardware_use = [time]
            hardware_use += self.psutil.cpu_percent(interval=1, percpu=True)
            hardware_use += [self.psutil.virtual_memory().used // (1024 ** 2)]
            self.csv_file.writerow(hardware_use)
            self.time.sleep(self.interval)
            self.check_per_hour()


    def check_per_hour(self):
        if self.hour != self.datetime.now().hour:
            self.hour = self.datetime.now().hour
            try:
                time = str(self.datetime.now(timezone('Brazil/East')))[:19].replace(' ', '_').replace(':', '_')
            except:
                time = str(self.datetime.now())[:19].replace(' ', '_').replace(':', '_')
            f = open('hardware_usage/%s.csv' % time, 'w')
            self.csv_file = self.csv.writer(f, delimiter=',')
            self.csv_file.writerow(self.header)
            f.flush()


    def check_dir(self, name):
        if isinstance(name, list):
            for n in name:
                if not self.os.path.isdir(n):
                    self.os.mkdir(n)
        else:
            if not self.os.path.isdir(name):
                self.os.mkdir(name)


    def run(self):
        thrd = self.Thread(target=self.get_hardware_usage())
        thrd.start()



scopes = [
	'https://www.googleapis.com/auth/firebase.database',
	'https://www.googleapis.com/auth/userinfo.email',
	'https://www.googleapis.com/auth/cloud-platform'
]


auth = ServiceAccountCredentials.from_json_keyfile_name('c.json', scopes)
config = {
	'apiKey': None,
	'authDomain': None,
	'databaseURL': 'https://dodvision.firebaseio.com',
	'storageBucket': None,
	'serviceAccount': 'c.json'
}

#db = Database(auth, None, 'https://dodvision.fiorebaseio.com',)

db = initialize_app(config).database()

def load_from_db():
#    os.system('pwd')
    personal_id = open('../.config', 'r').read().split('\n')[0]
    print('personal id', personal_id)
    while 1:
        print("Trying to load data from Firebase...")
        ret_from_db = (db.child('devices').get().val())
        ret_from_db = dict(ret_from_db)
        print(ret_from_db)

       # data = [val for _, val in ret_from_db.items()]
        #print(ret_from_db, data)
        for _, i in ret_from_db.items():
            if not i: continue
#            print(i)
#    print(i['deviceId'], personal_id)
            if i['deviceId'] == personal_id:
                    #BLINK PEGOU BANCO
#                    GPIO.output(2,GPIO.LOW)
 #                   sleep(2)
  #                  GPIO.output(2,GPIO.HIGH)
   #                 sleep(1)
    #                GPIO.output(2,GPIO.LOW)
     #               sleep(1)
      #              GPIO.output(2,GPIO.HIGH)
                    print("Encontrei!", list(i.values()))
                    return i['clientId'], i['storeId']
        print("Failed to load data from Firebase, sleeping for 1 second...")
        sleep(1)

cliente, loja = load_from_db()

#c = LiveController('pi_test', 'bs', '6:00-22:00')
#a = Camera('rtsp://admin:1234QWEr@192.168.1.141:554/12', 'porta', 'counter', 'pi_test', 'bs')

#a.start()
hw = hardware_usage() # You only need to create the object.

bs = count_people()
sum = 0
count = 0


#camera = PiCamera()
#camera.resolution = 640, 480
#print("RATE", camera.framerate)
#camera.framerate = 30
#stream = PiRGBArray(camera, size = camera.resolution)
queue = Queue()
#stream.truncate()
#stream.seek(0)
#n_frames = 0
#t = datetime.now()
#for i in camera.capture_continuous(stream, 'bgr'):

def add_event(op, t, cliente, loja): #TODO: Limpar e melhorar isso, tornar camera generica
		if op == 'up': op = 'entry'
		else: op = 'exit'
		timestamp = int(t.strftime("%s"))
		data = {'event': op, 'timestamp': int(timestamp), 'cameraId':'porta'}
		#self.buffer.append(data)
		queue.put(data)

class DatabaseThread(Process):
	def __init__(self):
		super().__init__()
		self.buffer = []
	def run(self):
		while 1:
	#		if not self.buffer: continue
	#		b = self.buffer[:]
	#		self.buffer.clear()
			while not queue.empty():
#			for i in b:
				i = queue.get()
				db.child('analytics').child('clients').child(cliente).child(loja).child('events').push(i)
#				print("BOOOOORA QUE DEU BOA!")



dbt = DatabaseThread()
dbt.start()
			
		
a = FrameInjector()
a.start()
print("Running BS")
while(1):
	tmp = a.fetch_buffer(1)
	if not tmp: continue
#	frame = tmp
	#n_frames += 1
	rets = [bs.principal(frame) for frame in tmp]
#	stream.seek(0)	

	print("BUFFER", len(rets))
	for ret in rets:
	        if not ret: continue
	        for count in ret:
	            t = datetime.now()
	            op = 'saida'
	            if count['direction'] == 'down': op = 'entrada'
	            add_event(op, t, cliente, loja)
             #      dbt.add_event(op, t, cliente, loja)
	            #db.child(path).child(name).update(data)
	            #hw.get_hardware_usage()
	            # BLINK PESSOA
	            #GPIO.output(2, GPIO.LOW)
	            #sleep(1)
            #GPIO.output(2, GPIO.HIGH)
	#print("Read", n_frames, "frames in ", datetime.now()  - t)
	#stream.truncate()
	#stream.seek(0)
	#n_frames = 0
	#t =datetime.now()

