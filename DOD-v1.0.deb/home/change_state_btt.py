import RPi.GPIO as GPIO
import time
from threading import Thread
from pi.wrapper import boot_wifi_setup, boot_access_point, boot_wifi
from module.wrapper import boot_module
GPIO.setmode(GPIO.BCM)

GPIO.setup(18, GPIO.IN, pull_up_down=GPIO.PUD_UP)

class Task(Thread):
	def __init__(self):
		super().__init__()

	def change_mode(self):
		print('asdasd', open('./.config', 'r').read().split('\n'))
		id, curr_mode = open('./.config', 'r').read().split('\n') 

		op = '1'
		if curr_mode == '1': op = '0'

		to_write = id + '\n' + op + '\n'
		with open('./.config', 'w') as f: f.write(to_write)
		if op == 1:
			print("Running access point...")
			boot_access_point()
		else:
			print("Running wifi...")			
			boot_wifi()
			
	def run_from_config(self):
		id, curr_mode, _ = open('./.config', 'r').read().split('\n') 
		if curr_mode == '1':
			print("Running server...")
			boot_wifi_setup()
		else:
			print("Running module...")
			boot_module()

	def run(self):
		self.run_from_config()
		while True:
			input_state = GPIO.input(18)
			if input_state == False:
				self.change_mode()
				print('Button Pressed')
				time.sleep(1)

t = Task()
t.run()
