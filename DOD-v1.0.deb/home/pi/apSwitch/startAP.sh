#!/bin/bash
#sudo wget -q https://raw.githubusercontent.com/xeenin/dodAP/master/installers/raspbian.sh
#sudo chmod +x /tmp/dodpi 
#/tmp/dodpi
#pwd
cd ./pi/apSwitch

sudo ./raspbian.sh

