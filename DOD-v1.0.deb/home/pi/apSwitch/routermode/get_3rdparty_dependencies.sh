#!/bin/bash

UPDATE_URL="https://raw.githubusercontent.com/xeenin/dodAP/master/"
wget -q ${UPDATE_URL}/installers/common.sh -O ./common.sh
