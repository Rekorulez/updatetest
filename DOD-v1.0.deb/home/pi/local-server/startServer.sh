#!/bin/bash
source activate
cd pi/local-server
python main.py

